if __name__ == "__main__":
    from bitsandbytes.diagnostics.main import main

    main()
